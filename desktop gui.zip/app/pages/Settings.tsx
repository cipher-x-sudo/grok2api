import { useState } from "react";
import { Eye, EyeOff, Loader2, Settings as SettingsIcon, CheckCircle2, Server, Key } from "lucide-react";

export function Settings() {
  const [baseUrl, setBaseUrl] = useState("http://localhost:8000");
  const [apiKey, setApiKey] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }, 800);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="h-12 border-b border-border flex items-center px-5 gap-3 shrink-0 bg-card/50">
        <SettingsIcon className="w-4 h-4 text-primary" />
        <span className="text-sm font-medium">API Setup</span>
        {saved && (
          <span className="ml-auto flex items-center gap-1.5 text-xs text-green-500">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Saved
          </span>
        )}
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-lg mx-auto px-5 py-8 space-y-6">
          <div>
            <h2 className="text-lg font-semibold mb-1">Connection Settings</h2>
            <p className="text-sm text-muted-foreground">
              Configure your Grok2API backend endpoint and authentication.
            </p>
          </div>

          <div className="gradio-panel p-5 space-y-5">
            <div>
              <label className="flex items-center gap-2 text-xs font-medium text-muted-foreground mb-1.5">
                <Server className="w-3.5 h-3.5" />
                Backend Base URL
              </label>
              <input
                type="text"
                value={baseUrl}
                onChange={(e) => setBaseUrl(e.target.value)}
                placeholder="http://localhost:8000"
                className="w-full gradio-input px-3 py-2.5 text-sm"
              />
            </div>

            <div>
              <label className="flex items-center gap-2 text-xs font-medium text-muted-foreground mb-1.5">
                <Key className="w-3.5 h-3.5" />
                API Access Key
              </label>
              <div className="relative">
                <input
                  type={showApiKey ? "text" : "password"}
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="sk-..."
                  className="w-full gradio-input px-3 py-2.5 pr-10 text-sm"
                />
                <button
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={handleSave}
            disabled={isSaving}
            className="gradio-button w-full flex items-center justify-center gap-2 text-sm"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Configuration"
            )}
          </button>

          {/* Info */}
          <div className="rounded-lg bg-primary/5 border border-primary/10 p-4">
            <p className="text-xs text-muted-foreground leading-relaxed">
              The backend should expose OpenAI-compatible endpoints at <code className="text-primary">/v1/chat/completions</code> and Anthropic-compatible endpoints at <code className="text-primary">/v1/messages</code>. Configuration is stored locally in your browser.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
