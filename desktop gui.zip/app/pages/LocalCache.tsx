import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  Trash2,
  AlertTriangle,
  Database,
  FolderOpen,
  Image as ImageIcon,
  Video,
  Download,
  Eye,
  X,
  Grid3X3,
  List,
} from "lucide-react";

interface CachedAsset {
  id: string;
  url: string;
  type: "image" | "video";
  prompt: string;
  size: string;
  date: string;
}

const INITIAL_ASSETS: CachedAsset[] = [
  { id: "1", url: "https://picsum.photos/seed/cache1/800/600", type: "image", prompt: "A beautiful sunset over mountains with vibrant colors", size: "2.4 MB", date: "2 hours ago" },
  { id: "2", url: "https://picsum.photos/seed/cache2/600/900", type: "image", prompt: "Cyberpunk cityscape at night with neon lights", size: "3.1 MB", date: "3 hours ago" },
  { id: "3", url: "https://picsum.photos/seed/cache3/900/600", type: "image", prompt: "Abstract geometric patterns in blue and purple", size: "1.8 MB", date: "5 hours ago" },
  { id: "4", url: "https://picsum.photos/seed/cache4/700/700", type: "image", prompt: "Minimalist modern architecture with clean lines", size: "2.7 MB", date: "6 hours ago" },
  { id: "5", url: "https://picsum.photos/seed/cache5/800/800", type: "image", prompt: "Futuristic AI robot in a laboratory setting", size: "3.5 MB", date: "8 hours ago" },
  { id: "6", url: "https://picsum.photos/seed/cache6/600/800", type: "image", prompt: "Nature landscape with flowing water and green forest", size: "2.2 MB", date: "1 day ago" },
];

export function LocalCache() {
  const [searchQuery, setSearchQuery] = useState("");
  const [fileType, setFileType] = useState<"all" | "images" | "videos">("all");
  const [showClearModal, setShowClearModal] = useState(false);
  const [assets, setAssets] = useState<CachedAsset[]>(INITIAL_ASSETS);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [previewAsset, setPreviewAsset] = useState<CachedAsset | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const filteredAssets = assets.filter((a) => {
    const matchType =
      fileType === "all" ||
      (fileType === "images" && a.type === "image") ||
      (fileType === "videos" && a.type === "video");
    return matchType && a.prompt.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const totalSize = "15.7 MB";

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const deleteSelected = () => {
    setAssets((prev) => prev.filter((a) => !selectedIds.has(a.id)));
    setSelectedIds(new Set());
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="h-12 border-b border-border flex items-center px-5 gap-3 shrink-0 bg-card/50">
        <Database className="w-4 h-4 text-primary" />
        <span className="text-sm font-medium">Local Cache</span>
        <span className="text-xs text-muted-foreground">
          {assets.length} assets &middot; {totalSize}
        </span>

        <div className="ml-auto flex items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search prompts..."
              className="gradio-input pl-8 pr-3 py-1.5 text-xs w-52"
            />
          </div>

          {/* Filter */}
          <select
            value={fileType}
            onChange={(e) => setFileType(e.target.value as any)}
            className="gradio-input px-2.5 py-1.5 text-xs cursor-pointer"
          >
            <option value="all">All</option>
            <option value="images">Images</option>
            <option value="videos">Videos</option>
          </select>

          {/* View toggle */}
          <div className="flex border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-1.5 transition-colors ${
                viewMode === "grid" ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-1.5 border-l border-border transition-colors ${
                viewMode === "list" ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Bulk actions */}
          {selectedIds.size > 0 && (
            <button
              onClick={deleteSelected}
              className="px-2.5 py-1.5 text-xs text-destructive bg-destructive/10 hover:bg-destructive/20 rounded-lg transition-colors"
            >
              Delete {selectedIds.size}
            </button>
          )}

          <button
            onClick={() => setShowClearModal(true)}
            className="px-2.5 py-1.5 text-xs text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
          >
            Clear All
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5">
        {filteredAssets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <FolderOpen className="w-12 h-12 text-muted-foreground/20 mb-3" />
            <h3 className="text-sm font-medium mb-1">No cached assets</h3>
            <p className="text-xs text-muted-foreground">
              Generated content will appear here
            </p>
          </div>
        ) : viewMode === "grid" ? (
          /* Grid View */
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            <AnimatePresence>
              {filteredAssets.map((asset, i) => (
                <motion.div
                  key={asset.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: i * 0.02 }}
                  className={`group relative rounded-xl overflow-hidden cursor-pointer border-2 transition-colors ${
                    selectedIds.has(asset.id) ? "border-primary" : "border-transparent"
                  }`}
                >
                  <div className="aspect-square bg-muted">
                    <img
                      src={asset.url}
                      alt={asset.prompt}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <p className="text-white text-[11px] line-clamp-2 mb-2">{asset.prompt}</p>
                      <div className="flex gap-1.5">
                        <button
                          onClick={(e) => { e.stopPropagation(); setPreviewAsset(asset); }}
                          className="flex-1 px-2 py-1 bg-white/20 backdrop-blur-md text-white rounded-md text-[11px] hover:bg-white/30 transition-colors flex items-center justify-center gap-1"
                        >
                          <Eye className="w-3 h-3" /> View
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); setAssets((p) => p.filter((a) => a.id !== asset.id)); }}
                          className="px-2 py-1 bg-white/20 backdrop-blur-md text-white rounded-md hover:bg-destructive/80 transition-colors"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Select checkbox */}
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleSelect(asset.id); }}
                    className={`absolute top-2 left-2 w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                      selectedIds.has(asset.id)
                        ? "bg-primary border-primary"
                        : "border-white/50 bg-black/20 opacity-0 group-hover:opacity-100"
                    }`}
                  >
                    {selectedIds.has(asset.id) && (
                      <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>

                  {/* Type badge */}
                  <div className="absolute top-2 right-2">
                    <div className="px-1.5 py-0.5 bg-black/40 backdrop-blur-sm text-white text-[10px] rounded flex items-center gap-1">
                      {asset.type === "image" ? <ImageIcon className="w-2.5 h-2.5" /> : <Video className="w-2.5 h-2.5" />}
                      {asset.size}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          /* List View */
          <div className="gradio-panel overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="w-10 py-2.5 px-3">
                    <input
                      type="checkbox"
                      checked={selectedIds.size === filteredAssets.length && filteredAssets.length > 0}
                      onChange={() => {
                        if (selectedIds.size === filteredAssets.length) {
                          setSelectedIds(new Set());
                        } else {
                          setSelectedIds(new Set(filteredAssets.map((a) => a.id)));
                        }
                      }}
                      className="accent-primary w-3.5 h-3.5 cursor-pointer"
                    />
                  </th>
                  <th className="text-left py-2.5 px-3 text-[11px] font-medium text-muted-foreground uppercase tracking-wider w-16">Preview</th>
                  <th className="text-left py-2.5 px-3 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Prompt</th>
                  <th className="text-left py-2.5 px-3 text-[11px] font-medium text-muted-foreground uppercase tracking-wider w-20">Type</th>
                  <th className="text-left py-2.5 px-3 text-[11px] font-medium text-muted-foreground uppercase tracking-wider w-20">Size</th>
                  <th className="text-left py-2.5 px-3 text-[11px] font-medium text-muted-foreground uppercase tracking-wider w-24">Created</th>
                  <th className="text-right py-2.5 px-3 text-[11px] font-medium text-muted-foreground uppercase tracking-wider w-24">Actions</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence>
                  {filteredAssets.map((asset) => (
                    <motion.tr
                      key={asset.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors"
                    >
                      <td className="py-2 px-3">
                        <input
                          type="checkbox"
                          checked={selectedIds.has(asset.id)}
                          onChange={() => toggleSelect(asset.id)}
                          className="accent-primary w-3.5 h-3.5 cursor-pointer"
                        />
                      </td>
                      <td className="py-2 px-3">
                        <img
                          src={asset.url}
                          alt=""
                          className="w-10 h-10 rounded-md object-cover cursor-pointer hover:opacity-80 transition-opacity"
                          onClick={() => setPreviewAsset(asset)}
                        />
                      </td>
                      <td className="py-2 px-3">
                        <p className="text-sm truncate max-w-xs">{asset.prompt}</p>
                      </td>
                      <td className="py-2 px-3">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          {asset.type === "image" ? <ImageIcon className="w-3 h-3" /> : <Video className="w-3 h-3" />}
                          {asset.type}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-xs text-muted-foreground">{asset.size}</td>
                      <td className="py-2 px-3 text-xs text-muted-foreground">{asset.date}</td>
                      <td className="py-2 px-3">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => setPreviewAsset(asset)}
                            className="p-1.5 hover:bg-muted rounded-md transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <a href={asset.url} download className="p-1.5 hover:bg-muted rounded-md transition-colors">
                            <Download className="w-3.5 h-3.5" />
                          </a>
                          <button
                            onClick={() => setAssets((p) => p.filter((a) => a.id !== asset.id))}
                            className="p-1.5 hover:bg-destructive/10 text-destructive rounded-md transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Preview Lightbox */}
      <AnimatePresence>
        {previewAsset && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-6"
            onClick={() => setPreviewAsset(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="relative max-w-4xl max-h-full"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setPreviewAsset(null)}
                className="absolute -top-10 right-0 p-1.5 text-white/70 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={previewAsset.url}
                alt={previewAsset.prompt}
                className="max-w-full max-h-[80vh] object-contain rounded-xl"
              />
              <div className="mt-3 flex items-center justify-between">
                <p className="text-white/80 text-sm max-w-lg truncate">{previewAsset.prompt}</p>
                <a
                  href={previewAsset.url}
                  download
                  className="px-3 py-1.5 bg-white/10 text-white text-xs rounded-lg hover:bg-white/20 transition-colors flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Clear Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="gradio-panel p-5 max-w-sm w-full space-y-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-destructive/10 rounded-lg flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">Clear All Cache</h3>
                <p className="text-xs text-muted-foreground">This cannot be undone</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowClearModal(false)}
                className="flex-1 px-3 py-2 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => { setAssets([]); setShowClearModal(false); }}
                className="flex-1 px-3 py-2 bg-destructive text-destructive-foreground rounded-lg text-sm hover:bg-destructive/90 transition-colors"
              >
                Delete All
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
