import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Send,
  Paperclip,
  ChevronDown,
  ChevronUp,
  X,
  Loader2,
  Sparkles,
  Brain,
  Bot,
  User,
} from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  thinking?: string;
  image?: string;
}

const MODELS = [
  { value: "grok-4.20-0309", label: "Grok 4.20", badge: "Chat" },
  { value: "grok-4.20-0309-reasoning", label: "Grok 4.20 Reasoning", badge: "Reason" },
  { value: "grok-4.20-multi-agent", label: "Grok 4.20 Multi-Agent", badge: "Agent" },
];

export function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [selectedModel, setSelectedModel] = useState("grok-4.20-0309");
  const [showReasoning, setShowReasoning] = useState(true);
  const [showThinking, setShowThinking] = useState<Record<string, boolean>>({});
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isGenerating]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setUploadedImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSend = () => {
    if (!input.trim() && !uploadedImage) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input || "Analyze this image",
      image: uploadedImage || undefined,
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setUploadedImage(null);
    setIsGenerating(true);

    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content:
            "This is a demo response from the Grok2API gateway. In production, this connects to your configured backend endpoint with the selected model.",
          thinking:
            selectedModel.includes("reasoning")
              ? "Step 1: Parse user intent → Step 2: Retrieve relevant context → Step 3: Formulate structured response with reasoning chain..."
              : undefined,
        },
      ]);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header bar */}
      <div className="h-12 border-b border-border flex items-center px-5 gap-3 shrink-0 bg-card/50">
        <Bot className="w-4 h-4 text-primary" />
        <span className="text-sm font-medium">Chat & Reason</span>
        <div className="ml-auto flex items-center gap-2">
          {MODELS.map((m) => (
            <button
              key={m.value}
              onClick={() => setSelectedModel(m.value)}
              className={`px-2.5 py-1 rounded-md text-xs transition-colors ${
                selectedModel === m.value
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`}
            >
              {m.label}
            </button>
          ))}
          <div className="w-px h-5 bg-border mx-1" />
          <button
            onClick={() => setShowReasoning(!showReasoning)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs transition-colors ${
              showReasoning
                ? "bg-primary/15 text-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            Thinking
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-5 py-6 space-y-5">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center py-24 text-center">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4">
                <Sparkles className="w-7 h-7 text-primary" />
              </div>
              <h2 className="text-lg font-semibold mb-1">Start a conversation</h2>
              <p className="text-sm text-muted-foreground max-w-sm">
                Choose a model above and type a message. Attach images for vision analysis.
              </p>
            </div>
          )}

          {messages.map((msg) => (
            <div key={msg.id} className="flex gap-3">
              <div
                className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center mt-0.5 ${
                  msg.role === "user"
                    ? "bg-primary/15"
                    : "bg-muted"
                }`}
              >
                {msg.role === "user" ? (
                  <User className="w-3.5 h-3.5 text-primary" />
                ) : (
                  <Bot className="w-3.5 h-3.5 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                {/* Thinking block */}
                {msg.role === "assistant" && msg.thinking && showReasoning && (
                  <div className="mb-2">
                    <button
                      onClick={() =>
                        setShowThinking((p) => ({ ...p, [msg.id]: !p[msg.id] }))
                      }
                      className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mb-1"
                    >
                      <Brain className="w-3 h-3 text-primary" />
                      <span>Thought process</span>
                      {showThinking[msg.id] ? (
                        <ChevronUp className="w-3 h-3" />
                      ) : (
                        <ChevronDown className="w-3 h-3" />
                      )}
                    </button>
                    <AnimatePresence>
                      {showThinking[msg.id] && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-3 py-2 rounded-lg bg-primary/5 border border-primary/10 text-xs text-muted-foreground italic leading-relaxed mb-2">
                            {msg.thinking}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {msg.image && (
                  <img
                    src={msg.image}
                    alt="Uploaded"
                    className="max-w-[240px] rounded-lg mb-2 border border-border"
                  />
                )}
                <p className="text-sm leading-relaxed">{msg.content}</p>
              </div>
            </div>
          ))}

          {isGenerating && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center shrink-0">
                <Bot className="w-3.5 h-3.5 text-muted-foreground" />
              </div>
              <div className="flex items-center gap-2 py-1">
                <Loader2 className="w-4 h-4 animate-spin text-primary" />
                <span className="text-xs text-muted-foreground">Generating...</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-border bg-card/50 px-5 py-3 shrink-0">
        <div className="max-w-3xl mx-auto">
          {uploadedImage && (
            <div className="mb-2 relative inline-block">
              <img
                src={uploadedImage}
                alt="Preview"
                className="w-14 h-14 rounded-lg object-cover border border-border"
              />
              <button
                onClick={() => setUploadedImage(null)}
                className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <div className="flex items-end gap-2 gradio-panel p-2">
            <label className="p-2 hover:bg-muted rounded-lg transition-colors cursor-pointer shrink-0">
              <Paperclip className="w-4 h-4 text-muted-foreground" />
              <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            </label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Type a message..."
              className="flex-1 bg-transparent px-2 py-1.5 resize-none min-h-[36px] max-h-[120px] focus:outline-none text-sm placeholder:text-muted-foreground"
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() && !uploadedImage}
              className="gradio-button px-3 py-1.5 flex items-center gap-1.5 text-sm shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
