import { useState } from "react";
import { RefreshCw, Trash2, Users, Activity, HardDrive, Shield } from "lucide-react";

interface Account {
  id: string;
  tier: "Basic" | "Super" | "Heavy";
  status: "Active" | "Rate Limited" | "Offline";
  lastSynced: string;
}

const INITIAL_ACCOUNTS: Account[] = [
  { id: "ACC001", tier: "Super", status: "Active", lastSynced: "2 min ago" },
  { id: "ACC002", tier: "Heavy", status: "Active", lastSynced: "5 min ago" },
  { id: "ACC003", tier: "Basic", status: "Rate Limited", lastSynced: "10 min ago" },
  { id: "ACC004", tier: "Super", status: "Offline", lastSynced: "1 hr ago" },
];

export function AdminAccounts() {
  const [accounts, setAccounts] = useState<Account[]>(INITIAL_ACCOUNTS);
  const [showDeleteModal, setShowDeleteModal] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState<string | null>(null);

  const handleRefresh = (id: string) => {
    setRefreshing(id);
    setTimeout(() => {
      setAccounts((p) => p.map((a) => (a.id === id ? { ...a, lastSynced: "Just now" } : a)));
      setRefreshing(null);
    }, 800);
  };

  const handleDelete = (id: string) => {
    setAccounts((p) => p.filter((a) => a.id !== id));
    setShowDeleteModal(null);
  };

  const active = accounts.filter((a) => a.status === "Active").length;
  const limited = accounts.filter((a) => a.status === "Rate Limited").length;

  const metrics = [
    { icon: Users, label: "Accounts", value: accounts.length, color: "text-primary" },
    { icon: Activity, label: "Active", value: active, color: "text-green-500" },
    { icon: HardDrive, label: "Cache", value: "1.4 GB", color: "text-chart-3" },
    { icon: Shield, label: "Auth Mode", value: "Super", color: "text-chart-4" },
  ];

  const tierClass = (t: string) =>
    t === "Basic"
      ? "bg-muted text-muted-foreground"
      : t === "Super"
      ? "bg-chart-4/15 text-chart-4"
      : "bg-chart-3/15 text-chart-3";

  const statusClass = (s: string) =>
    s === "Active"
      ? "text-green-500"
      : s === "Rate Limited"
      ? "text-destructive"
      : "text-orange-400";

  return (
    <div className="h-full flex flex-col">
      <div className="h-12 border-b border-border flex items-center px-5 gap-3 shrink-0 bg-card/50">
        <Users className="w-4 h-4 text-primary" />
        <span className="text-sm font-medium">Admin & Accounts</span>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-5 py-6 space-y-6">
          {/* Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {metrics.map((m) => (
              <div key={m.label} className="gradio-panel p-4 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg bg-muted/50 flex items-center justify-center shrink-0`}>
                  <m.icon className={`w-4 h-4 ${m.color}`} />
                </div>
                <div>
                  <div className="text-lg font-semibold leading-tight">{m.value}</div>
                  <div className="text-[11px] text-muted-foreground">{m.label}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Rate limit bar */}
          <div className="gradio-panel p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground">Rate Limit Usage</span>
              <span className="text-xs font-semibold">67%</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full transition-all" style={{ width: "67%" }} />
            </div>
          </div>

          {/* Table */}
          <div className="gradio-panel overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <h3 className="text-sm font-medium">Account Pool</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    <th className="text-left py-2.5 px-4 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">ID</th>
                    <th className="text-left py-2.5 px-4 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Tier</th>
                    <th className="text-left py-2.5 px-4 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                    <th className="text-left py-2.5 px-4 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Synced</th>
                    <th className="text-right py-2.5 px-4 text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {accounts.map((acc) => (
                    <tr key={acc.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="py-2.5 px-4 text-sm font-mono">{acc.id}</td>
                      <td className="py-2.5 px-4">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${tierClass(acc.tier)}`}>
                          {acc.tier}
                        </span>
                      </td>
                      <td className="py-2.5 px-4">
                        <span className={`text-sm ${statusClass(acc.status)}`}>{acc.status}</span>
                      </td>
                      <td className="py-2.5 px-4 text-sm text-muted-foreground">{acc.lastSynced}</td>
                      <td className="py-2.5 px-4">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleRefresh(acc.id)}
                            disabled={refreshing === acc.id}
                            className="p-1.5 hover:bg-muted rounded-md transition-colors disabled:opacity-50"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${refreshing === acc.id ? "animate-spin" : ""}`} />
                          </button>
                          <button
                            onClick={() => setShowDeleteModal(acc.id)}
                            className="p-1.5 hover:bg-destructive/10 text-destructive rounded-md transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="gradio-panel p-5 max-w-sm w-full space-y-4">
            <h3 className="text-sm font-semibold">Remove Account</h3>
            <p className="text-sm text-muted-foreground">
              This will remove the account from the pool. Continue?
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowDeleteModal(null)}
                className="flex-1 px-3 py-2 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/80 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(showDeleteModal)}
                className="flex-1 px-3 py-2 bg-destructive text-destructive-foreground rounded-lg text-sm hover:bg-destructive/90 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
